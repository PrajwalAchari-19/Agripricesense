// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'landing_page.dart'; // Import LandingPage
// // import 'package:agriprice/pages/home_page.dart';
// import 'login_page.dart';
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp();
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'AgriPriceSense',
//       theme: ThemeData(
//         primarySwatch: Colors.green,
//       ),
//       home: LandingPage(), // Start with the LandingPage (Splash Screen)
//     );
//   }
// }
//
// class AuthStateHandler extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final user = FirebaseAuth.instance.currentUser; // Check the current user
//     if (user != null) {
//       return HomePage(); // Redirect to HomePage if logged in
//     } else {
//       return LoginPage(); // Redirect to LoginPage if not logged in
//     }
//   }
// }

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'landing_page.dart'; // Import LandingPage
import 'login_page.dart';
import 'home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Initialize Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AgriPriceSense',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: LandingPage(), // Start with the LandingPage (Splash Screen)
    );
  }
}

// Handles Authentication State and redirects to the appropriate page
class AuthStateHandler extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser; // Check the current user
    if (user != null) {
      return HomePage(); // Redirect to HomePage if logged in
    } else {
      return LoginPage(); // Redirect to LoginPage if not logged in
    }
  }
}

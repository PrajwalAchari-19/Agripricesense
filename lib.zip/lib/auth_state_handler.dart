// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'home_page.dart';
// import 'login_page.dart';
//
// class AuthStateHandler extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final user = FirebaseAuth.instance.currentUser; // Check the current user
//     if (user != null) {
//       return HomePage(); // Redirect to HomePage if logged in
//     } else {
//       return LoginPage(); // Redirect to LoginPage if not logged in
//     }
//   }
// }

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'home_page.dart';
import 'login_page.dart';

class AuthStateHandler extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(), // Listen for auth state changes
      builder: (context, snapshot) {
        // Show a loading indicator while checking authentication status
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        // If the user is logged in, navigate to the HomePage
        if (snapshot.hasData && snapshot.data != null) {
          return HomePage();
        }

        // If no user is logged in, navigate to the LoginPage
        return LoginPage();
      },
    );
  }
}

// import 'package:flutter/material.dart';
//
// class MandiPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text(
//           'Real-time crop prices will be displayed here.',
//           style: TextStyle(fontSize: 18),
//         ),
//       ),
//     );
//   }
// }
//
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MandiPage extends StatefulWidget {
  @override
  _MandiPageState createState() => _MandiPageState();
}

class _MandiPageState extends State<MandiPage> {
  String? selectedState;
  String? selectedDistrict;
  String? selectedMandi;
  DateTime selectedDate = DateTime.now();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController districtController = TextEditingController();
  final TextEditingController mandiController = TextEditingController();
  List<Map<String, String>> fetchedData = [];
  bool isLoading = false;
  bool hasError = false;
  String errorMessage = '';

  // Fetch data from Flask API
  Future<void> fetchData() async {
    setState(() {
      isLoading = true;
      hasError = false;
      errorMessage = '';
    });

    String state = stateController.text.isNotEmpty ? stateController.text : (selectedState ?? '');
    String district = districtController.text.isNotEmpty ? districtController.text : (selectedDistrict ?? '');
    String mandi = mandiController.text.isNotEmpty ? mandiController.text : (selectedMandi ?? '');
    String formattedDate = "${selectedDate.year}-${selectedDate.month.toString().padLeft(2, '0')}-${selectedDate.day.toString().padLeft(2, '0')}";

    if (state.isEmpty || district.isEmpty || mandi.isEmpty) {
      setState(() {
        hasError = true;
        errorMessage = 'Please provide state, district, and mandi details.';
        isLoading = false;
      });
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('http://10.9.97.173:5000/get-data'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'state': state,
          'district': district,
          'mandi': mandi,
          'date': formattedDate,
        }),
      );

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse['status'] == 'success') {
          setState(() {
            fetchedData = List<Map<String, String>>.from(jsonResponse['data']);
          });
        } else {
          throw Exception(jsonResponse['message']);
        }
      } else {
        throw Exception('Failed to fetch data. HTTP status code: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        hasError = true;
        errorMessage = e.toString();
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Date Picker
  Future<void> selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mandi Prices'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: stateController,
                decoration: InputDecoration(labelText: 'Enter State (Optional if dropdown used)'),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedState,
                items: ['Telangana', 'Andhra Pradesh', 'Karnataka'].map((state) {
                  return DropdownMenuItem(value: state, child: Text(state));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedState = value;
                  });
                },
                decoration: InputDecoration(labelText: 'Select State'),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: districtController,
                decoration: InputDecoration(labelText: 'Enter District (Optional if dropdown used)'),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedDistrict,
                items: ['Hyderabad', 'Warangal', 'Karimnagar'].map((district) {
                  return DropdownMenuItem(value: district, child: Text(district));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedDistrict = value;
                  });
                },
                decoration: InputDecoration(labelText: 'Select District'),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: mandiController,
                decoration: InputDecoration(labelText: 'Enter Mandi (Optional if dropdown used)'),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedMandi,
                items: ['Market 1', 'Market 2', 'Market 3'].map((mandi) {
                  return DropdownMenuItem(value: mandi, child: Text(mandi));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedMandi = value;
                  });
                },
                decoration: InputDecoration(labelText: 'Select Mandi'),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  TextButton(
                    onPressed: () => selectDate(context),
                    child: Text('Select Date: ${selectedDate.toLocal()}'.split(' ')[0]),
                  ),
                ],
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: fetchData,
                child: Text('Fetch Prices'),
              ),
              SizedBox(height: 20),
              if (isLoading)
                Center(child: CircularProgressIndicator())
              else if (hasError)
                Center(child: Text('Error: $errorMessage', style: TextStyle(color: Colors.red))),
              if (!isLoading && !hasError && fetchedData.isNotEmpty)
                DataTable(
                  columns: [
                    DataColumn(label: Text('Commodity')),
                    DataColumn(label: Text('Max Price')),
                    DataColumn(label: Text('Avg Price')),
                    DataColumn(label: Text('Min Price')),
                  ],
                  rows: fetchedData.map((row) {
                    return DataRow(cells: [
                      DataCell(Text(row['Commodity'] ?? '')),
                      DataCell(Text(row['Maximum Price'] ?? '')),
                      DataCell(Text(row['Average Price'] ?? '')),
                      DataCell(Text(row['Minimum Price'] ?? '')),
                    ]);
                  }).toList(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}



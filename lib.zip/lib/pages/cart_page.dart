import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          'Your selected items will appear here.',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}

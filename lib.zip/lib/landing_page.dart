// import 'package:flutter/material.dart'; // Necessary import for the UI components
// import 'auth_state_handler.dart'; // Correct import for the AuthStateHandler
//
// class LandingPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     // Delay for 2 seconds before navigating
//     Future.delayed(Duration(seconds: 2), () {
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => AuthStateHandler()),
//       );
//     });
//
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: Center(
//         child: Image.asset(
//           'assets/logo.png', // Path to your logo image
//           height: 300, // Adjust the size as needed
//           width: 300,  // Adjust the size as needed
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart'; // Necessary import for UI components
import 'package:firebase_auth/firebase_auth.dart'; // Import FirebaseAuth
import 'home_page.dart'; // Import for the HomePage
import 'login_page.dart'; // Import for the LoginPage

class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Check the authentication state and navigate accordingly
    Future.delayed(Duration(seconds: 2), () async {
      bool isLoggedIn = await _isUserLoggedIn();
      if (isLoggedIn) {
        // Navigate to HomePage if authenticated
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      } else {
        // Navigate to LoginPage if not authenticated
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      }
    });

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset(
          'assets/logo.png', // Path to your logo image
          height: 300, // Adjust the size as needed
          width: 300, // Adjust the size as needed
        ),
      ),
    );
  }

  // Static method to check if the user is logged in
  Future<bool> _isUserLoggedIn() async {
    final user = FirebaseAuth.instance.currentUser; // Get the current user
    return user != null; // Return true if the user is not null (logged in)
  }
}


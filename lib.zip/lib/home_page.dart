import 'package:flutter/material.dart';
import 'pages/mandi_page.dart';
import 'pages/cart_page.dart';
import 'pages/profile_page.dart';
import 'pages/home_page_content.dart'; // Home content page

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;  // Current tab index

  // List of pages for the BottomNavigationBar
  final List<Widget> _pages = [
    HomePageContent(),  // Home Content
    MandiPage(),        // Mandi Page
    CartPage(),         // Cart Page
    ProfilePage(),      // Profile Page
  ];

  // Handle the tab tap and update the index
  void _onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_currentIndex], // Display the selected page
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onTabTapped, // Handle tab selection
        items: [
          _buildBottomNavItem(Icons.home, 'Home', 0),        // Updated Home icon
          _buildBottomNavItem(Icons.store, 'Mandi', 1),      // Store-like icon for Mandi
          _buildBottomNavItem(Icons.shopping_basket, 'Cart', 2), // Shopping basket icon for Cart
          _buildBottomNavItem(Icons.account_circle, 'Profile', 3), // Account circle icon for Profile
        ],
        selectedItemColor: Colors.green,  // Selected icon color
        unselectedItemColor: Colors.grey, // Unselected icon color
        backgroundColor: Colors.white,  // Keep the background white
        type: BottomNavigationBarType.fixed, // Keep labels
        elevation: 0, // Remove shadow for a flat look
      ),
    );
  }

  // Helper method to build BottomNavigationBarItem with scaling effect
  BottomNavigationBarItem _buildBottomNavItem(IconData icon, String label, int index) {
    double scale = _currentIndex == index ? 1.2 : 1.0; // Scale the icon when selected

    return BottomNavigationBarItem(
      icon: AnimatedScale(
        scale: scale,  // Apply scale animation
        duration: Duration(milliseconds: 200), // Duration of animation
        child: Icon(
          icon,
          size: 28, // Icon size
          color: _currentIndex == index
              ? Colors.green // Selected icon color
              : Colors.grey, // Unselected icon color
        ),
      ),
      label: label,  // Display label under the icon
    );
  }
}
